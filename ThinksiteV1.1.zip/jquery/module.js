	// 页面渲染模块
	// 渲染方法
	function appendHtml(datas){
		var html_ = '<tr>'+
						'<td>' +
							'<input type="checkbox">' +
							'<span>'+ datas.id +'</span>' +
						'</td>' +
						'<td>' +
						   '<input class="inp" type="text" value="'+ datas.name +'" disabled>' +
						'</td>' +
						'<td>' +
							'<input class="inp" type="text" value="'+ datas.age +'" disabled>' +
						'</td>' +
						'<td>' +
							'<input class="inp" type="text" value="'+ datas.height +'" disabled>' +
						'</td>' +
						'<td>' +
							'<input class="inp" type="text" value="'+ datas.weight +'" disabled>' +
						'</td>' +
						'<td>' +
							'<input type="button" value="删除" class="del">' +
						'</td>' +
					'</tr>';
		return html_;
	}
	
	// 选择性渲染

	function selFun(datas, fun, name){
		if(datas.length == 1){
			$(name).append(fun(datas[0]));  // 添加一条记录
		} else {
			$(name).html('');
			$.each(datas, function(key, val){
				$(name).append(fun(val));
			})
		}
	}
	

	// 录入为空判断模块
    function empTest(names, error){
		var status = 0;
	
		$.each(names, function(key, val){
			if($(val).val() == ''){
				status += 1;
			} else {
				status += 0;
			}
		})
		if(status > 0){
			$(error).show();
			return false;
		}
		else {
			$(error).hide();
			var data = {
				name: $(names.name).val(),
				age: $(names.age).val(),
				height: $(names.height).val(),
				weight: $(names.weight).val()
			}		
			return data;				
		}
		status = 0; 
	}	
	
	
	// 清空输入框
	
	function empInp(names){
		$.each(names, function(key, val){
			$(val).val("");
		})		
	}
	
	// 获取ID
	
	function getId(datas){
		var id = -1;
		$.each(datas, function(key, val){
			if(id < val.id){
				id = val.id;
			}
		})
		
		return id;
	}
	
